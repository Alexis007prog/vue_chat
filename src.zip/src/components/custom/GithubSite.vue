<template>
  <div class="text-neutral-400">
    <span>Star on</span>
  </div>
</template>
